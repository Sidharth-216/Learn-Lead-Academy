import { useState, useEffect } from "react";
import { Plus, Pencil, Trash2, Search, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { adminApi, type Course } from "@/lib/api";
import { toast } from "sonner";

type CourseForm = {
  title: string; category: string; description: string; instructor: string;
  duration: string; lessonCount: number; price: number; rating: number;
  thumbnailUrl: string; isPublished: boolean;
};

const emptyForm: CourseForm = {
  title: "", category: "", description: "", instructor: "",
  duration: "", lessonCount: 0, price: 0, rating: 0,
  thumbnailUrl: "", isPublished: false,
};

const AdminCourses = () => {
  const [courses,       setCourses]       = useState<Course[]>([]);
  const [total,         setTotal]         = useState(0);
  const [page,          setPage]          = useState(1);
  const [totalPages,    setTotalPages]    = useState(1);
  const [search,        setSearch]        = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [loading,       setLoading]       = useState(true);
  const [saving,        setSaving]        = useState(false);
  const [deleting,      setDeleting]      = useState<string | null>(null);
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);
  const [formData,      setFormData]      = useState<CourseForm>(emptyForm);
  const [dialogOpen,    setDialogOpen]    = useState(false);

  // Debounce search
  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(search), 400);
    return () => clearTimeout(t);
  }, [search]);

  // Load courses
  useEffect(() => {
    setLoading(true);
    adminApi.getAdminCourses({ page, pageSize: 20, search: debouncedSearch || undefined })
      .then((res) => {
        setCourses(res.items);
        setTotal(res.total);
        setTotalPages(res.totalPages);
      })
      .catch((err) => toast.error(err.message ?? "Failed to load courses."))
      .finally(() => setLoading(false));
  }, [page, debouncedSearch]);

  const openAdd = () => {
    setEditingCourse(null);
    setFormData(emptyForm);
    setDialogOpen(true);
  };

  const openEdit = (course: Course) => {
    setEditingCourse(course);
    setFormData({
      title:        course.title,
      category:     course.category,
      description:  course.description,
      instructor:   course.instructor,
      duration:     course.duration,
      lessonCount:  course.lessonCount,
      price:        course.price,
      rating:       course.rating,
      thumbnailUrl: course.thumbnailUrl ?? "",
      isPublished:  course.isPublished,
    });
    setDialogOpen(true);
  };

  const handleSave = async () => {
    if (!formData.title.trim() || !formData.category.trim()) {
      toast.error("Title and category are required.");
      return;
    }
    setSaving(true);
    try {
      const payload = { ...formData, thumbnailUrl: formData.thumbnailUrl || undefined };
      if (editingCourse) {
        const updated = await adminApi.updateCourse(editingCourse.id, payload);
        setCourses((prev) => prev.map((c) => c.id === editingCourse.id ? updated : c));
        toast.success(`"${updated.title}" updated.`);
      } else {
        const created = await adminApi.createCourse(payload);
        setCourses((prev) => [created, ...prev]);
        setTotal((t) => t + 1);
        toast.success(`"${created.title}" created.`);
      }
      setDialogOpen(false);
    } catch (err: any) {
      toast.error(err.message ?? "Failed to save course.");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (course: Course) => {
    if (!confirm(`Delete "${course.title}"? This cannot be undone.`)) return;
    setDeleting(course.id);
    try {
      await adminApi.deleteCourse(course.id);
      setCourses((prev) => prev.filter((c) => c.id !== course.id));
      setTotal((t) => t - 1);
      toast.success(`"${course.title}" deleted.`);
    } catch (err: any) {
      toast.error(err.message ?? "Failed to delete course.");
    } finally {
      setDeleting(null);
    }
  };

  const f = (field: keyof CourseForm, val: string | number | boolean) =>
    setFormData((prev) => ({ ...prev, [field]: val }));

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display font-bold text-3xl text-foreground">Manage Courses</h1>
          <p className="text-muted-foreground mt-1">{total} courses total</p>
        </div>
        <Button onClick={openAdd} className="bg-hero text-primary-foreground hover:opacity-90">
          <Plus className="w-4 h-4 mr-2" /> Add Course
        </Button>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search courses..."
          value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(1); }}
          className="pl-10"
        />
      </div>

      <Card className="shadow-card">
        <CardContent className="p-0">
          {loading ? (
            <div className="flex justify-center py-16">
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Title</TableHead>
                  <TableHead className="hidden md:table-cell">Category</TableHead>
                  <TableHead className="hidden lg:table-cell">Instructor</TableHead>
                  <TableHead className="hidden md:table-cell">Students</TableHead>
                  <TableHead className="hidden lg:table-cell">Price</TableHead>
                  <TableHead className="hidden sm:table-cell">Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {courses.map((course) => (
                  <TableRow key={course.id}>
                    <TableCell className="font-medium text-foreground max-w-[200px] truncate">{course.title}</TableCell>
                    <TableCell className="hidden md:table-cell text-muted-foreground">{course.category}</TableCell>
                    <TableCell className="hidden lg:table-cell text-muted-foreground">{course.instructor}</TableCell>
                    <TableCell className="hidden md:table-cell text-muted-foreground">{course.studentCount.toLocaleString()}</TableCell>
                    <TableCell className="hidden lg:table-cell text-muted-foreground">₹{course.price.toLocaleString()}</TableCell>
                    <TableCell className="hidden sm:table-cell">
                      <Badge variant={course.isPublished ? "default" : "secondary"}
                        className={course.isPublished ? "bg-green-500/15 text-green-700 border-green-200" : ""}>
                        {course.isPublished ? "Published" : "Draft"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1">
                        <Button variant="ghost" size="icon" onClick={() => openEdit(course)}>
                          <Pencil className="w-4 h-4 text-primary" />
                        </Button>
                        <Button
                          variant="ghost" size="icon"
                          onClick={() => handleDelete(course)}
                          disabled={deleting === course.id}
                        >
                          {deleting === course.id
                            ? <Loader2 className="w-4 h-4 animate-spin" />
                            : <Trash2 className="w-4 h-4 text-destructive" />}
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
                {courses.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                      No courses found.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex justify-center gap-2">
          <Button variant="outline" size="sm" onClick={() => setPage((p) => Math.max(1, p-1))} disabled={page === 1}>Previous</Button>
          <span className="flex items-center text-sm text-muted-foreground px-2">Page {page} of {totalPages}</span>
          <Button variant="outline" size="sm" onClick={() => setPage((p) => Math.min(totalPages, p+1))} disabled={page === totalPages}>Next</Button>
        </div>
      )}

      {/* Add / Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-display">
              {editingCourse ? "Edit Course" : "Add New Course"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label>Title *</Label>
              <Input value={formData.title} onChange={(e) => f("title", e.target.value)} />
            </div>
            <div>
              <Label>Category *</Label>
              <Input value={formData.category} onChange={(e) => f("category", e.target.value)} placeholder="e.g. Web Development" />
            </div>
            <div>
              <Label>Description</Label>
              <Textarea value={formData.description} onChange={(e) => f("description", e.target.value)} rows={3} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Instructor</Label>
                <Input value={formData.instructor} onChange={(e) => f("instructor", e.target.value)} />
              </div>
              <div>
                <Label>Duration</Label>
                <Input value={formData.duration} onChange={(e) => f("duration", e.target.value)} placeholder="e.g. 8 weeks" />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label>Lessons</Label>
                <Input type="number" min={0} value={formData.lessonCount} onChange={(e) => f("lessonCount", Number(e.target.value))} />
              </div>
              <div>
                <Label>Price (₹)</Label>
                <Input type="number" min={0} value={formData.price} onChange={(e) => f("price", Number(e.target.value))} />
              </div>
              <div>
                <Label>Rating</Label>
                <Input type="number" step="0.1" min={0} max={5} value={formData.rating} onChange={(e) => f("rating", Number(e.target.value))} />
              </div>
            </div>
            <div>
              <Label>Thumbnail URL</Label>
              <Input value={formData.thumbnailUrl} onChange={(e) => f("thumbnailUrl", e.target.value)} placeholder="https://..." />
            </div>
            <div className="flex items-center gap-3">
              <Switch
                checked={formData.isPublished}
                onCheckedChange={(v) => f("isPublished", v)}
                id="published-switch"
              />
              <Label htmlFor="published-switch">Published (visible to students)</Label>
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">Cancel</Button>
            </DialogClose>
            <Button onClick={handleSave} disabled={saving} className="bg-hero text-primary-foreground hover:opacity-90">
              {saving
                ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Saving...</>
                : editingCourse ? "Save Changes" : "Create Course"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminCourses;
