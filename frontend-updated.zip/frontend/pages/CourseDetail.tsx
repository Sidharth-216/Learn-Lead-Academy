import { useEffect, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { ArrowLeft, Clock, Users, BookOpen, Star, Play, Download, Loader2, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { coursesApi, userApi, authApi, type Course } from "@/lib/api";
import { toast } from "sonner";

const sampleLessons = [
  { title: "Introduction & Setup",       duration: "15 min", free: true  },
  { title: "Core Concepts",              duration: "45 min", free: false },
  { title: "Hands-on Project 1",         duration: "60 min", free: false },
  { title: "Advanced Techniques",        duration: "50 min", free: false },
  { title: "Real-World Application",     duration: "55 min", free: false },
  { title: "Final Project & Assessment", duration: "90 min", free: false },
];

const CourseDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [course, setCourse] = useState<Course | null>(null);
  const [loading, setLoading] = useState(true);
  const [enrolling, setEnrolling] = useState(false);
  const [enrolled, setEnrolled] = useState(false);
  const [error, setError] = useState("");

  // Load course data
  useEffect(() => {
    if (!id) return;
    setLoading(true);
    coursesApi
      .getById(id)
      .then(setCourse)
      .catch((err) => setError(err.message ?? "Course not found."))
      .finally(() => setLoading(false));
  }, [id]);

  // Check if already enrolled (only when logged in)
  useEffect(() => {
    if (!id || !authApi.isLoggedIn()) return;
    userApi.getEnrollments().then((enrollments) => {
      setEnrolled(enrollments.some((e) => e.courseId === id));
    }).catch(() => {});
  }, [id]);

  const handleEnroll = async () => {
    if (!authApi.isLoggedIn()) {
      navigate(`/login?tab=signup`);
      return;
    }
    if (!id) return;
    setEnrolling(true);
    try {
      await userApi.enroll(id);
      setEnrolled(true);
      toast.success("Successfully enrolled! Head to your dashboard to start learning.");
      navigate("/dashboard");
    } catch (err: any) {
      toast.error(err.message ?? "Enrollment failed. Please try again.");
    } finally {
      setEnrolling(false);
    }
  };

  // ── Loading state ──────────────────────────────────────────────────────────
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  // ── Error / not found ──────────────────────────────────────────────────────
  if (error || !course) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground text-lg mb-4">{error || "Course not found."}</p>
          <Link to="/courses">
            <Button variant="outline">Browse Courses</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Navbar />
      <div className="pt-20">
        {/* Hero */}
        <div className="bg-hero py-16">
          <div className="container mx-auto px-4">
            <Link
              to="/courses"
              className="inline-flex items-center gap-2 text-primary-foreground/70 hover:text-primary-foreground mb-6 text-sm"
            >
              <ArrowLeft className="w-4 h-4" /> Back to Courses
            </Link>
            <div className="max-w-3xl">
              <span className="px-3 py-1 rounded-full bg-accent/20 border border-accent/30 text-xs font-semibold text-accent">
                {course.category}
              </span>
              <h1 className="font-display font-bold text-3xl md:text-5xl text-primary-foreground mt-4 mb-4">
                {course.title}
              </h1>
              <p className="text-primary-foreground/70 mb-6 leading-relaxed">{course.description}</p>
              <div className="flex flex-wrap items-center gap-6 text-sm text-primary-foreground/70">
                <span className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-accent text-accent" />
                  {course.rating.toFixed(1)} rating
                </span>
                <span className="flex items-center gap-1">
                  <Users className="w-4 h-4" />
                  {course.studentCount.toLocaleString()} students
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  {course.duration}
                </span>
                <span className="flex items-center gap-1">
                  <BookOpen className="w-4 h-4" />
                  {course.lessonCount} lessons
                </span>
              </div>
              <p className="text-sm text-primary-foreground/60 mt-3">Instructor: {course.instructor}</p>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="container mx-auto px-4 py-12">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Left – Curriculum & Resources */}
            <div className="lg:col-span-2">
              <h2 className="font-display font-bold text-2xl text-foreground mb-6">Course Curriculum</h2>
              <div className="space-y-3">
                {sampleLessons.map((lesson, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between p-4 rounded-xl bg-card border border-border hover:shadow-card transition-shadow"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-lg bg-secondary flex items-center justify-center">
                        <Play className="w-4 h-4 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium text-sm text-foreground">{lesson.title}</p>
                        <p className="text-xs text-muted-foreground">{lesson.duration}</p>
                      </div>
                    </div>
                    {lesson.free && (
                      <span className="text-xs font-medium text-accent bg-accent/10 px-2 py-1 rounded-full">
                        Free
                      </span>
                    )}
                  </div>
                ))}
              </div>

              <h2 className="font-display font-bold text-2xl text-foreground mt-12 mb-6">Resources</h2>
              <div className="flex flex-col gap-3">
                {["Course Notes (PDF)", "Practice Exercises", "Project Starter Files"].map((r) => (
                  <div
                    key={r}
                    className="flex items-center justify-between p-4 rounded-xl bg-card border border-border"
                  >
                    <span className="text-sm text-foreground">{r}</span>
                    <Button variant="ghost" size="sm">
                      <Download className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>

            {/* Right – Enroll card */}
            <div>
              <div className="sticky top-24 p-6 rounded-2xl bg-card border border-border shadow-elevated">
                <p className="font-display font-bold text-3xl text-primary mb-1">
                  ₹{course.price.toLocaleString()}
                </p>
                <p className="text-sm text-muted-foreground mb-6">One-time payment • Lifetime access</p>

                {enrolled ? (
                  <div className="w-full flex items-center justify-center gap-2 py-4 rounded-xl bg-green-50 border border-green-200 text-green-700 font-semibold text-sm">
                    <CheckCircle className="w-5 h-5" />
                    You are enrolled
                  </div>
                ) : (
                  <Button
                    onClick={handleEnroll}
                    disabled={enrolling}
                    className="w-full bg-gold-gradient text-accent-foreground font-display font-bold rounded-xl py-6 text-lg shadow-gold"
                  >
                    {enrolling
                      ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Enrolling...</>
                      : authApi.isLoggedIn() ? "Enroll Now" : "Sign up to Enroll"}
                  </Button>
                )}

                <div className="mt-6 space-y-3 text-sm text-muted-foreground">
                  <p>✓ Certificate of completion</p>
                  <p>✓ Lifetime access to materials</p>
                  <p>✓ Internship assistance</p>
                  <p>✓ 1-on-1 mentorship sessions</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default CourseDetail;
